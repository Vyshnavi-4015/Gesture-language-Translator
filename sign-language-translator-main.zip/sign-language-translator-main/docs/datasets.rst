Sign Language Datasets
======================

For our datasets, see the `sign-language-datasets repository <https://github.com/sign-language-translator/sign-language-datasets>`_ and its `releases <https://github.com/sign-language-translator/sign-language-datasets/releases>`_.
