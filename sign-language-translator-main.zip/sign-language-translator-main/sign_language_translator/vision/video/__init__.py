from sign_language_translator.vision.video.video import Video

__all__ = [
    "Video",
]
